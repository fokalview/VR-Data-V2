// ============================================================================
// STYLING FUNCTIONS - Determine colors, sizes, and box dimensions
// ============================================================================

// ============================================================================
// COLOR FUNCTION - Determine what color each node should be based on its type
// ============================================================================
export const getNodeColor = (node) => {
  // Root node (leftmost, "All Users") - GREEN
  if (!node.parent) {
    return '#4CAF50';
  }

  // Gender nodes (first branch level) - colored by gender
  if (node.parent && !node.parent.parent) {
    if (node.data.label === 'Male') {
      return '#2196F3'; // BLUE for Male
    } else if (node.data.label === 'Female') {
      return '#E91E63'; // PINK for Female
    } else {
      return '#FF9800'; // ORANGE for Other
    }
  }

  // Metric nodes (rightmost leaves) - LIGHT BLUE
  return '#B3E5FC';
};

// ============================================================================
// BOX DIMENSION FUNCTION - Calculate width and height for node rectangles
// ============================================================================
export const calculateNodeBoxDimensions = (node) => {
  // Get the label and value text
  const label = node.data.label;
  const value = node.data.value || '';

  // Estimate width based on longest text
  const labelWidth = label.length * 6;
  const valueWidth = value.length * 5.5;
  const maxTextWidth = Math.max(labelWidth, valueWidth);

  // Add horizontal padding
  const width = maxTextWidth + 16;

  // Fixed height for two lines of text
  const height = 52;

  return { width, height };
};
