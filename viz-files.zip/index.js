// ============================================================================
// ENTRY POINT - Loads React and renders the main App component
// ============================================================================

import { createElement } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App.js';

// Find the root element in HTML and attach React to it
const root = createRoot(document.getElementById('root'));

// Render the App component
root.render(createElement(App));
