// ============================================================================
// MAIN APP COMPONENT
// Handles data loading and rendering three tree visualizations (one per headset)
// ============================================================================

import {
  useRef,
  useEffect,
  useState,
  createElement,
} from 'react';
import { csv } from 'd3';
import { TreeDiagram } from './TreeDiagram.js';

const App = () => {
  // References to the three SVG elements where we will draw the trees
  const svgRefPSVR = useRef();
  const svgRefOculus = useRef();
  const svgRefHTC = useRef();

  // State to store the loaded data
  const [data, setData] = useState([]);

  // ========================================================================
  // STEP 1: Load and prepare the data when component first appears
  // ========================================================================
  useEffect(() => {
    // Load CSV file from public folder
    csv('Virtual Reality Experiences.csv').then(
      (rawData) => {
        // Convert text numbers to actual numbers
        const cleanData = rawData.map((row) => ({
          ...row,
          Age: +row.Age,
          MotionSickness: +row.MotionSickness,
          Duration: +row.Duration,
          ImmersionLevel: +row.ImmersionLevel,
        }));

        // Store in state
        setData(cleanData);
      },
    );
  }, []);

  // ========================================================================
  // STEP 2: Draw the trees when data is ready
  // ========================================================================
  useEffect(() => {
    // Only draw if we have data
    if (data.length === 0) return;

    // Filter data for each headset
    const psvrData = data.filter(
      (row) => row.VRHeadset === 'PlayStation VR',
    );
    const oculusData = data.filter(
      (row) => row.VRHeadset === 'Oculus Rift',
    );
    const htcData = data.filter(
      (row) => row.VRHeadset === 'HTC Vive',
    );

    // Draw the three tree diagrams
    if (svgRefPSVR.current && psvrData.length > 0) {
      TreeDiagram(svgRefPSVR.current, psvrData);
    }
    if (svgRefOculus.current && oculusData.length > 0) {
      TreeDiagram(svgRefOculus.current, oculusData);
    }
    if (svgRefHTC.current && htcData.length > 0) {
      TreeDiagram(svgRefHTC.current, htcData);
    }
  }, [data]);

  // ========================================================================
  // STEP 3: Return three SVG canvases side by side
  // ========================================================================
  return createElement(
    'div',
    {
      style: {
        display: 'flex',
        gap: '20px',
        flexWrap: 'wrap',
        justifyContent: 'center',
      },
    },
    createElement('svg', {
      ref: svgRefPSVR,
      width: 520,
      height: 800,
      style: { flex: '1 1 500px' },
    }),
    createElement('svg', {
      ref: svgRefOculus,
      width: 520,
      height: 800,
      style: { flex: '1 1 500px' },
    }),
    createElement('svg', {
      ref: svgRefHTC,
      width: 520,
      height: 800,
      style: { flex: '1 1 500px' },
    }),
  );
};

export { App };
