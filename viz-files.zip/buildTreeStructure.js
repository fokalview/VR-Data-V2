// ============================================================================
// BUILD TREE STRUCTURE - Converts scatter plot data into hierarchical format
// ============================================================================

export const buildTreeStructure = (data) => {
  // ========================================================================
  // STEP 1: Group all users by their gender
  // ========================================================================
  const genderGroups = {};

  data.forEach((person) => {
    const gender = person.Gender;

    // Create empty array for this gender if it doesn't exist
    if (!genderGroups[gender]) {
      genderGroups[gender] = [];
    }

    // Add person to their gender group
    genderGroups[gender].push(person);
  });

  // ========================================================================
  // STEP 2: Create the root node (leftmost of tree)
  // ========================================================================
  const root = {
    label: 'All Users',
    value: `${data.length}`,
    children: [],
  };

  // ========================================================================
  // STEP 3: Create a branch for each gender
  // ========================================================================
  Object.keys(genderGroups).forEach((gender) => {
    const groupData = genderGroups[gender];

    // Create gender node
    const genderNode = {
      label: gender,
      value: `${groupData.length}`,
      children: [],
    };

    // Calculate averages for this gender group
    const stats = calculateAverages(groupData);

    // ====================================================================
    // STEP 4: Create child nodes for each metric under this gender
    // ====================================================================

    // Age metric
    const ageNode = {
      label: 'Average Age',
      value: stats.avgAge,
      children: [],
    };

    // Motion Sickness metric
    const sickNessNode = {
      label: 'Average Motion Sickness',
      value: stats.avgMotionSickness,
      children: [],
    };

    // Duration metric
    const durationNode = {
      label: 'Average Duration',
      value: stats.avgDuration,
      children: [],
    };

    // Immersion Level metric
    const immersionNode = {
      label: 'Average Immersion',
      value: stats.avgImmersion,
      children: [],
    };

    // ====================================================================
    // STEP 5: Attach all metrics as children of gender node
    // ====================================================================
    genderNode.children.push(
      ageNode,
      sickNessNode,
      durationNode,
      immersionNode,
    );

    // ====================================================================
    // STEP 6: Attach gender node as child of root
    // ====================================================================
    root.children.push(genderNode);
  });

  return root;
};

// ============================================================================
// HELPER FUNCTION - Calculate average values for a group of people
// ============================================================================
const calculateAverages = (people) => {
  // Add up all values for each metric
  let totalAge = 0;
  let totalMotionSickness = 0;
  let totalDuration = 0;
  let totalImmersion = 0;

  people.forEach((person) => {
    totalAge += person.Age;
    totalMotionSickness += person.MotionSickness;
    totalDuration += person.Duration;
    totalImmersion += person.ImmersionLevel;
  });

  // Divide by number of people to get average
  const count = people.length;

  // Return all averages as strings with 1 decimal place
  return {
    avgAge: `${(totalAge / count).toFixed(1)} yrs`,
    avgMotionSickness: `${(totalMotionSickness / count).toFixed(1)}/10`,
    avgDuration: `${(totalDuration / count).toFixed(1)} min`,
    avgImmersion: `${(totalImmersion / count).toFixed(1)}/5`,
  };
};
