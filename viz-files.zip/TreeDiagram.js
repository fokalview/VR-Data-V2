// ============================================================================
// TREE DIAGRAM - Creates a clean horizontal left-to-right tree visualization
// ============================================================================

import { select, hierarchy, tree } from 'd3';
import { buildTreeStructure } from './buildTreeStructure.js';
import {
  getNodeColor,
  calculateNodeBoxDimensions,
} from './styling.js';

// ============================================================================
// LAYOUT CONSTANTS - Easy to adjust spacing and sizing
// ============================================================================

// Horizontal spread from left to right (in pixels)
const HORIZONTAL_SPREAD = 450;

// Vertical spread for spacing gender and metric nodes
const VERTICAL_SPREAD = 700;

// Left margin (distance from left edge of SVG)
const LEFT_MARGIN = 20;

// Top margin (distance from top edge, below title)
const TOP_MARGIN = 70;

// Title position from top of SVG
const TITLE_Y = 25;

// Title font size
const TITLE_FONT_SIZE = '18px';

// Node label font size
const LABEL_FONT_SIZE = '13px';

// Node value font size
const VALUE_FONT_SIZE = '11px';

// Rounded corner radius for node boxes
const BOX_BORDER_RADIUS = 6;

// Box border width
const BOX_BORDER_WIDTH = 1.5;

// Connecting line stroke width
const LINE_STROKE_WIDTH = 2;

export const TreeDiagram = (svgElement, data) => {
  // ========================================================================
  // STEP 1: Convert raw data into tree structure
  // ========================================================================
  const treeStructure = buildTreeStructure(data);

  // ========================================================================
  // STEP 2: Create a HORIZONTAL tree layout (rotated 90 degrees)
  // ========================================================================
  const treeLayout = tree().size([
    VERTICAL_SPREAD,
    HORIZONTAL_SPREAD,
  ]);

  // Convert tree structure into D3 hierarchy
  const hierarchyRoot = hierarchy(treeStructure);

  // Apply tree layout (calculates x, y positions for each node)
  treeLayout(hierarchyRoot);

  // ========================================================================
  // STEP 3: Select SVG and clear previous content
  // ========================================================================
  const svg = select(svgElement);
  svg.selectAll('*').remove();

  // ========================================================================
  // STEP 4: Add title centered at top with padding
  // ========================================================================
  svg
    .append('text')
    .attr('x', 260) // Half of SVG width for centering
    .attr('y', TITLE_Y)
    .attr('text-anchor', 'middle')
    .attr('dominant-baseline', 'hanging')
    .style('font-size', TITLE_FONT_SIZE)
    .style('font-weight', 'bold')
    .style('fill', '#222')
    .text(getHeadsetTitle(data));

  // ========================================================================
  // STEP 5: Create main group with margins for the tree
  // ========================================================================
  const mainGroup = svg
    .append('g')
    .attr(
      'transform',
      `translate(${LEFT_MARGIN}, ${TOP_MARGIN})`,
    );

  // ========================================================================
  // STEP 6: Draw connecting lines between parent and child nodes
  // ========================================================================
  mainGroup
    .selectAll('path.link')
    .data(hierarchyRoot.links())
    .join('path')
    .attr('class', 'link')
    .attr('d', (d) => {
      const midpointX =
        d.source.y + (d.target.y - d.source.y) / 2;
      return `M${d.source.y},${d.source.x}
              L${midpointX},${d.source.x}
              L${midpointX},${d.target.x}
              L${d.target.y},${d.target.x}`;
    })
    .attr('fill', 'none')
    .attr('stroke', '#999')
    .attr('stroke-width', LINE_STROKE_WIDTH)
    .attr('opacity', 0.7);

  // ========================================================================
  // STEP 7: Create groups for each node (box + text container)
  // ========================================================================
  const nodeGroups = mainGroup
    .selectAll('g.node')
    .data(hierarchyRoot.descendants())
    .join('g')
    .attr('class', 'node')
    .attr('transform', (d) => `translate(${d.y}, ${d.x})`);

  // ========================================================================
  // STEP 8: Draw rectangle boxes for each node with padding
  // ========================================================================
  nodeGroups
    .append('rect')
    .attr('class', 'node-box')
    .attr('x', (d) => {
      const { width } = calculateNodeBoxDimensions(d);
      return -width / 2;
    })
    .attr('y', (d) => {
      const { height } = calculateNodeBoxDimensions(d);
      return -height / 2;
    })
    .attr(
      'width',
      (d) => calculateNodeBoxDimensions(d).width,
    )
    .attr(
      'height',
      (d) => calculateNodeBoxDimensions(d).height,
    )
    .attr('rx', BOX_BORDER_RADIUS)
    .attr('ry', BOX_BORDER_RADIUS)
    .attr('fill', (d) => getNodeColor(d))
    .attr('stroke', '#333')
    .attr('stroke-width', BOX_BORDER_WIDTH);

  // ========================================================================
  // STEP 9: Add main label text (node name)
  // ========================================================================
  nodeGroups
    .append('text')
    .attr('class', 'node-label')
    .attr('text-anchor', 'middle')
    .attr('dominant-baseline', 'middle')
    .attr('dy', '-4px')
    .style('font-size', LABEL_FONT_SIZE)
    .style('font-weight', 'bold')
    .style('fill', '#000')
    .style('pointer-events', 'none')
    .text((d) => d.data.label);

  // ========================================================================
  // STEP 10: Add value text (numbers) below the label
  // ========================================================================
  nodeGroups
    .append('text')
    .attr('class', 'node-value')
    .attr('text-anchor', 'middle')
    .attr('dominant-baseline', 'middle')
    .attr('dy', '8px')
    .style('font-size', VALUE_FONT_SIZE)
    .style('font-weight', '500')
    .style('fill', '#444')
    .style('pointer-events', 'none')
    .text((d) => (d.data.value ? d.data.value : ''));
};

// ============================================================================
// HELPER FUNCTION - Determine the title based on headset type
// ============================================================================
const getHeadsetTitle = (data) => {
  if (data.length === 0) return 'No Data';
  const headset = data[0].VRHeadset;
  return `${headset} Users`;
};
